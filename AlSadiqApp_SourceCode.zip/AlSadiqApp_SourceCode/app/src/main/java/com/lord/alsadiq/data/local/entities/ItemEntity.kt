package com.lord.alsadiq.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.Index

@Entity(
    tableName = "items",
    indices = [Index(value = ["name"], unique = true)]
)
data class ItemEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val unit: String,
    val currentStock: Double = 0.0,
    val defaultSalePrice: Long = 0L,
    val minStockThreshold: Double = 10.0,
    val isArchived: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
