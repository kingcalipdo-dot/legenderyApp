package com.lord.alsadiq.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.ForeignKey

@Entity(
    tableName = "sales",
    foreignKeys = [
        ForeignKey(
            entity = ItemEntity::class,
            parentColumns = ["id"],
            childColumns = ["itemId"],
            onDelete = ForeignKey.RESTRICT
        )
    ]
)
data class SaleEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val itemId: Long,
    val quantity: Double,
    val unitPrice: Long,
    val unitCost: Long,
    val discount: Long = 0L,
    val subtotal: Long,
    val finalTotal: Long,
    val totalCostOfGoodsSold: Long,
    val grossProfit: Long,
    val notes: String? = null,
    val timestamp: Long = System.currentTimeMillis(),
    val isCancelled: Boolean = false,
    val cancellationReason: String? = null
)
