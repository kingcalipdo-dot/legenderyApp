package com.lord.alsadiq.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class MovementType {
    OPENING_BALANCE,
    PURCHASE,
    SALE,
    PURCHASE_RETURN,
    SALE_RETURN,
    ADJUSTMENT,
    REVERSAL
}

@Entity(tableName = "stock_movements")
data class StockMovementEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val itemId: Long,
    val movementType: MovementType,
    val quantityChange: Double,
    val referenceId: Long? = null,
    val unitCostSnapshot: Long? = null,
    val notes: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)
