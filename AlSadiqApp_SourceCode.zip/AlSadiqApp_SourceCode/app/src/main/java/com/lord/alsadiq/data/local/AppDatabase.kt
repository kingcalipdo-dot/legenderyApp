package com.lord.alsadiq.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.lord.alsadiq.data.local.dao.AppDao
import com.lord.alsadiq.data.local.entities.*

@Database(
    entities = [
        ItemEntity::class,
        PurchaseEntity::class,
        SaleEntity::class,
        StockMovementEntity::class,
        ExpenseEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun appDao(): AppDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "alsadiq_database.db"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
