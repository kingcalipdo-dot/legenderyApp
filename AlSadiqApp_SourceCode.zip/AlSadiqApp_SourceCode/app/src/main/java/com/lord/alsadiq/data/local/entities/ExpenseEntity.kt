package com.lord.alsadiq.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "expenses")
data class ExpenseEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val category: String,
    val amount: Long,
    val description: String,
    val notes: String? = null,
    val timestamp: Long = System.currentTimeMillis(),
    val isCancelled: Boolean = false
)
