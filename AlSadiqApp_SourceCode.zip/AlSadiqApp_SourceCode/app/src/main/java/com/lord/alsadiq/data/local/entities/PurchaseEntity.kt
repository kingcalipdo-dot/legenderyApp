package com.lord.alsadiq.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.ForeignKey

@Entity(
    tableName = "purchases",
    foreignKeys = [
        ForeignKey(
            entity = ItemEntity::class,
            parentColumns = ["id"],
            childColumns = ["itemId"],
            onDelete = ForeignKey.RESTRICT
        )
    ]
)
data class PurchaseEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val itemId: Long,
    val quantity: Double,
    val unitPrice: Long,
    val totalCost: Long,
    val additionalCosts: Long = 0L,
    val supplierName: String? = null,
    val supplierInvoiceNumber: String? = null,
    val notes: String? = null,
    val timestamp: Long = System.currentTimeMillis(),
    val isCancelled: Boolean = false
)
