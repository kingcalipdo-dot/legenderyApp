package com.lord.alsadiq.data.local.dao

import androidx.room.*
import com.lord.alsadiq.data.local.entities.*
import kotlinx.coroutines.flow.Flow

@Dao
interface AppDao {
    @Query("SELECT * FROM items WHERE isArchived = 0 ORDER BY name ASC")
    fun getActiveItems(): Flow<List<ItemEntity>>

    @Query("SELECT * FROM items ORDER BY name ASC")
    fun getAllItems(): Flow<List<ItemEntity>>

    @Query("SELECT * FROM items WHERE id = :id")
    suspend fun getItemById(id: Long): ItemEntity?

    @Query("SELECT * FROM items WHERE name = :name LIMIT 1")
    suspend fun getItemByName(name: String): ItemEntity?

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertItem(item: ItemEntity): Long

    @Update
    suspend fun updateItem(item: ItemEntity)

    @Query("UPDATE items SET currentStock = currentStock + :quantityDelta WHERE id = :itemId")
    suspend fun updateStock(itemId: Long, quantityDelta: Double)

    @Insert
    suspend fun insertPurchase(purchase: PurchaseEntity): Long

    @Query("SELECT * FROM purchases WHERE itemId = :itemId ORDER BY timestamp DESC")
    fun getPurchasesForItem(itemId: Long): Flow<List<PurchaseEntity>>

    @Insert
    suspend fun insertSale(sale: SaleEntity): Long

    @Query("SELECT * FROM sales WHERE id = :id")
    suspend fun getSaleById(id: Long): SaleEntity?

    @Query("SELECT * FROM sales WHERE itemId = :itemId ORDER BY timestamp DESC")
    fun getSalesForItem(itemId: Long): Flow<List<SaleEntity>>

    @Query("UPDATE sales SET isCancelled = 1, cancellationReason = :reason WHERE id = :saleId")
    suspend fun markSaleAsCancelled(saleId: Long, reason: String)

    @Insert
    suspend fun insertStockMovement(movement: StockMovementEntity): Long

    @Query("SELECT * FROM stock_movements WHERE itemId = :itemId ORDER BY timestamp DESC")
    fun getMovementsForItem(itemId: Long): Flow<List<StockMovementEntity>>

    @Insert
    suspend fun insertExpense(expense: ExpenseEntity): Long

    @Query("SELECT * FROM expenses WHERE isCancelled = 0 AND timestamp BETWEEN :startTime AND :endTime ORDER BY timestamp DESC")
    fun getExpensesBetween(startTime: Long, endTime: Long): Flow<List<ExpenseEntity>>
}
